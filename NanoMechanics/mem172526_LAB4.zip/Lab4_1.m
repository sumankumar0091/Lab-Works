clc;
clear all;
close all;
r0=3.84;
A=.8;

d=input('Enter a number 1 to 3 :');
switch d
    case 1
        argon_nmer=fopen('lab4Ar4_1.xyz','wt');
        m=1;
        for theta=0:12:360
            fprintf(argon_nmer,'20\n');
            fprintf(argon_nmer,'20mer \n');
            for n=1:1:20
                u(n)=A*sin(0.2992*m*n)*cos(theta*pi/180);% u=Asin(m*2*pi*r*n/21)*e^(iwt);
                fprintf(argon_nmer,'Ar   ');
                fprintf(argon_nmer,'%f',n*r0+u(n));
                fprintf(argon_nmer,' 0.000 0.000 \n');
            end
        end
         fclose(argon_nmer);
    case 2
        argon_nmer=fopen('lab4Ar4_2.xyz','wt');
         m=2;
        for theta=0:12:360
        fprintf(argon_nmer,'20\n');
        fprintf(argon_nmer,'20mer \n');
            for n=1:1:20
           u(n)=A*sin(0.2992*m*n)*cos(theta*pi/180);
            fprintf(argon_nmer,'Ar   ');
            fprintf(argon_nmer,'%f',n*r0+u(n));
            fprintf(argon_nmer,' 0.000 0.000 \n');
            end
        end
         fclose(argon_nmer);
    case 3
        argon_nmer=fopen('lab4Ar4_3.xyz','wt');
        m=5;
        for theta=0:12:360
        fprintf(argon_nmer,'20\n');
        fprintf(argon_nmer,'20mer \n');
            for n=1:1:20
               u(n)=A*sin(0.2992*m*n)*cos(theta*pi/180);
                fprintf(argon_nmer,'Ar   ');
                fprintf(argon_nmer,'%f',n*r0+u(n));
                fprintf(argon_nmer,' 0.000 0.000 \n');
            end
        end
         fclose(argon_nmer);
   
    otherwise
        disp ('Enter a Valid Number');  
end



