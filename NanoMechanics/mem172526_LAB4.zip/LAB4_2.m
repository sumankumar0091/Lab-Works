clc
clear all
close all
N=1:1:20;
w0=0.8e12;
fArCr=fopen('modefreq.xyz','wt');
A=.8;
u=zeros(20,1);
X=[1:1:20]*3.84;
m=1;
for theta=0:12:360
    fprintf(fArCr,'20\n');
    fprintf(fArCr,'Ar Nmer \n');

for N=1:1:20
  
W(N)=2*w0*abs(sin(2*pi*m*N/42));
u(N)=A*sin(0.2992*m*N)*cos(theta*pi/180);
fprintf(fArCr,'Ar ');
fprintf(fArCr,'%f',X(N)+u(N));
fprintf(fArCr,'0  0\n');
end
end
fprintf('Modal frequency for %g',m);
fprintf(' the mode is %g \n',W(N));
fclose(fArCr);