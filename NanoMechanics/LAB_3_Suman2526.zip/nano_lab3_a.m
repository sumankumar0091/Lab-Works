clc;
clear all;
close all;
r0=3.84;
A=.8;

d=input('Enter a number 1 to 5  :');
switch d
    case 1
        argon_nmer=fopen('lab3Ar3_1.xyz','wt');
        m=1;
        for theta=0:12:360;
            fprintf(argon_nmer,'20\n');
            fprintf(argon_nmer,'20mer \n');
            for n=1:1:20;
                u(n)=A*cos(0.3142*m*n-theta*0.0175);% u=Acos(m*2*pi*r*n/20-theta)
                fprintf(argon_nmer,'Ar   ');
                fprintf(argon_nmer,'%f',n*r0+u(n));
                fprintf(argon_nmer,' 0.000 0.000 \n');
            end
        end
         fclose(argon_nmer);
    case 2
        argon_nmer=fopen('lab3Ar3_2.xyz','wt');
         m=2;
        for theta=0:12:360;
        fprintf(argon_nmer,'20\n');
        fprintf(argon_nmer,'20mer \n');
            for n=1:1:20;
            u(n)=A*cos(0.3142*m*n-theta*0.0175);% u=Acos(m*2*pi*r*n/20-theta)
            fprintf(argon_nmer,'Ar   ');
            fprintf(argon_nmer,'%f',n*r0+u(n));
            fprintf(argon_nmer,' 0.000 0.000 \n');
            end
        end
         fclose(argon_nmer);
    case 3
        argon_nmer=fopen('lab3Ar3_5.xyz','wt');
        m=5;
        for theta=0:12:360;
        fprintf(argon_nmer,'20\n');
        fprintf(argon_nmer,'20mer \n');
            for n=1:1:20;
                u(n)=A*cos(0.3142*m*n-theta*0.0175);% u=Acos(m*2*pi*r*n/20-theta)
                fprintf(argon_nmer,'Ar   ');
                fprintf(argon_nmer,'%f',n*r0+u(n));
                fprintf(argon_nmer,' 0.000 0.000 \n');
            end
        end
         fclose(argon_nmer);
    case 4
        argon_nmer=fopen('lab3Ar3_10.xyz','wt');
         m=10;
        for theta=0:12:360;
        fprintf(argon_nmer,'20\n');
        fprintf(argon_nmer,'20mer \n');
            for n=1:1:20;
            u(n)=A*cos(0.3142*m*n-theta*0.0175);% u=Acos(m*2*pi*r*n/20-theta)
            fprintf(argon_nmer,'Ar   ');
            fprintf(argon_nmer,'%f',n*r0+u(n));
            fprintf(argon_nmer,' 0.000 0.000 \n');
            end
        end
         fclose(argon_nmer);
    case 5
        argon_nmer=fopen('lab3Ar3_20.xyz','wt');
        m=20;
        for theta=0:12:360;
        fprintf(argon_nmer,'20\n');
        fprintf(argon_nmer,'20mer \n');
            for n=1:1:20;
            u(n)=A*cos(0.3142*m*n-theta*0.0175);% u=Acos(m*2*pi*r*n/20-theta)
            fprintf(argon_nmer,'Ar   ');
            fprintf(argon_nmer,'%f',n*r0+u(n));
            fprintf(argon_nmer,' 0.000 0.000 \n');
            end
        end
 fclose(argon_nmer);
    otherwise
        disp ('Enter a Valid Number');  
end



