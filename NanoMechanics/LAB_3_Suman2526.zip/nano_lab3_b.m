clc
clear all
close all
r0=3.84;
q=-pi/2:pi/30:pi/2;
a=sqrt(2-2*cos(q*r0));%w/w0
b=q*r0;

subplot(1,2,1);
figure (1);
plot(q*180/pi,a);
hold on
plot(q*180/pi,abs(b));
title('Dispertion Relation-eigen frequency Vs wave vector');
xlabel('angle in degrees');
ylabel('omega/omega0');
hold on
subplot(1,2,2)
plot(q*180/pi,abs(b));
title('Linear relation eigen frequency Vs wave vector');
xlabel('angle in degrees');
ylabel('omega/omega0');