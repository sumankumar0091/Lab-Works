clc
clear all
close all
Cu_nmer = fopen('CuLab5_3.xyz','w');

fprintf(Cu_nmer,'5610\n');
for p=0:1:100
    if(mod(p,2)==0)
        for q=0:1:10
            if(mod(q,2)==0)
            for r=0:1:5
                x=3.6*r;
                y=q*1.8;
                z=p*1.8;
                fprintf(Cu_nmer,'Copper  ');
                fprintf(Cu_nmer,'%f   ',x);
                fprintf(Cu_nmer,'%f   ',y);
                fprintf(Cu_nmer,'%f   ',z);
                fprintf(Cu_nmer,'\n');
            end

            else
            for r=1:1:5
            x=1.8+3.6*(r-1);
            y=1.8+1.8*(q-1);
            z=p*1.8;
            fprintf(Cu_nmer,'Copper  ');
            fprintf(Cu_nmer,'%f   ',x);
            fprintf(Cu_nmer,'%f   ',y);
            fprintf(Cu_nmer,'%f   ',z);
            fprintf(Cu_nmer,' \n');
        end
        end
    end
    else
        for(q=1:1:10)
            if(mod(q,2)==0)
                for r=1:1:5
                    x=1.8+3.6*(r-1);
                    y=1.8*(q-1);
                    z=1.8+1.8*(p-1);
                    fprintf(Cu_nmer,'Copper  ');
                    fprintf(Cu_nmer,'%f   ',x);
                    fprintf(Cu_nmer,'%f   ',y);
                    fprintf(Cu_nmer,'%f   ',z);
                    fprintf(Cu_nmer,' \n');
                end
    else
        for r=0:1:5
                    x=3.6*r;
                    y=1.8+1.8*(q-1);
                    z=1.8+1.8*(p-1);
                    fprintf(Cu_nmer,'Copper  ');
                    fprintf(Cu_nmer,'%f  ',x);
                    fprintf(Cu_nmer,'%f  ',y);
                    fprintf(Cu_nmer,'%f  ',z);
                    fprintf(Cu_nmer,' \n');
                end
     end


        end
    end
end
fclose(Cu_nmer);