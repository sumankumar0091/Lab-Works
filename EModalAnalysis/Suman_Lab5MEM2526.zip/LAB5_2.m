clc;
clear all; 
close all;
file1= 'Prc05_ch1.csv';
data1= csvread(file1);
F_t=data1(:,2);
% figure(1)
% plot(F_t)
 
file2= 'Prc05_ch2.csv';
data2= csvread(file2);
X_t=data2(:,2);
hold on
% figure(2)
% plot(X_t)
L=length(F_t);
t= data1(:,1);
dt=t(L)-t(1);
df=1/dt;
w=2*pi*(1:L/2)*df;
F_w=fft(F_t);
X_w=fft(X_t);
% plot(w,abs(X_w(1:L/2)));
H_w=X_w./F_w;
H_w=H_w/length(H_w);
% figure(1)
plot(w, abs(H_w(1:L/2)));
 
%half power method
figure(1)
height= max(abs(H_w))/sqrt(2)*ones(1,1000);
scale=2*pi*(26.002:0.002:28);
plot(scale,height);
hold on;

wa=27.27;
wb=27.35;
 
 
%Structural Damping
 
eta_1=2*(wb-wa)/(wb+wa);eta_2=.5*eta_1; %input('eta 2..?   ');
f= [27.31 171];
syms gamma;
gamma= solve(eta_1-gamma/f(1)^2-eta_2+gamma/f(2)^2);
gamma=double(gamma)
beta=eta_1-gamma/f(1)^2
 
 
% viscous damping
 
zeta_1=2*2*(wb-wa)/(wb+wa)
zeta_2=0.5*zeta_1 
f= [27.31 171];
syms beta;
beta=solve(2*zeta_1*f(1)-beta*f(1)^2-2*zeta_2*f(2)+beta*f(2)^2);
beta= double(beta)
gamma=2*zeta_1*f(1)-beta*f(1)^2
 
 
N= 20; 
b=0.047;
t=0.005;
rho=7850;
E=19e10;
A=b*t; 
I=(b*t^3)/12; 
Le=0.385;
L=Le/N;
 

k=(E*I/(L^3))*[12, 6*L, -12, 6*L; 6*L, 4*L^2, -6*L, 2*L^2; -12, -6*L, 12, -6*L; 6*L, 2*L^2, -6*L, 4*L^2];
k1=(E*I/(L^3))*[24, 0, -12, 6*L; 0, 8*L^2, -6*L, 2*L^2; -12, -6*L, 24, 0; 6*L, 2*L^2, 0, 8*L^2];
 

m=(rho*A*L/420)*[156, 22*L, 54, -13*L; 22*L, 4*L^2, 13*L, -3*L^2; 54, 13*L, 156, -22*L; -13*L, -3*L^2, -22*L, 4*L^2];
m1=(rho*A*L/420)*[312, 0, 54, -13*L; 0, 8*L^2, 13*L, -3*L^2; 54, 13*L, 312, 0; -13*L, -3*L^2, 0, 8*L^2];
 
for i=1:4
    for j=1:4
            K(i,j)=k(i,j);
            K(2*N-2+i,2*N-2+j)=k(i,j);
    end
end
for n=1:(N-2)
    for i=1:4
          for j=1:4
          K(i+2*n,j+2*n)=k1(i,j);
          end
    end
end
for i=1:4
    for j=1:4
            M(i,j)=m(i,j);
            M(2*N-2+i,2*N-2+j)=m(i,j);
    end
end
for n=1:(N-1)
    for i=1:4
          for j=1:4
          M(i+2*n,j+2*n)=m1(i,j);
          end
    end
end

    K(1,:)=[];
    K(1,:)=[];
    K(:,1)=[];
    K(:,1)=[]; 
    M(1,:)=[];
    M(1,:)=[]; 
    M(:,1)=[];
    M(:,1)=[]; 
 
K=K*(1+1i*beta)+gamma*M;
[V,D]=eig(K,M);
omegaN=diag(sqrt(real(D)))/(2*pi);
sort(omegaN);
f1= omegaN(length(omegaN))
f2=omegaN(length(omegaN)-1)
 
 
 
 
 
% Structural Damping
 
for p=1:1250;
alpha(:,:,p)=(K-(w(p)^2).*M)^(-1)*6.2061e+08;
end

hold off
hold on
grid on
plot(w, abs(H_w(1:1250)));
title('Experimental FRF');
 
plot(w,abs(squeeze(alpha(1,1,:))));
hold off
title('Receptance for response and excitation at first dof')
xlabel('frequency rad/s ')
ylabel('magnitude of \alpha')
legend('experimental data','line for identification of half power points','FEM predicted data')
 
 
%Viscous Damping
 
for p=1:1250;
alpha(:,:,p)=(K-(w(p)^2).*M)^(1)*3.3040e+07;
end
plot(w,abs(squeeze(alpha(1,1,:))));
title('Receptance for response and excitation at first dof')
xlabel('frequency rad/s ')
ylabel('magnitude of \alpha')
legend('experimental data','line for identification of half power points','FEM predicted data')

