clc
clear all
close all
m1=1;m2=2;
eta=0.2;
m=[m1 0;0 m2];
k1=10e3; k2=80e3;k3=10e3;
k=[k1+k2 -k2;-k2 k2+k3];
[V,D]=eig(m\k);%[eigen vector eigen value];
OmgN=D.^0.5;
% syms w
% recep=inv((k*(1+eta*1i)-w^2*m)); %w=omega;
% 
a= 20:1:400;
for p= 1:1:length(a)
   w=a(p);%algular frequency
alp11(p)=(-(w^2 - 45000 - 9000i)/(w^4 - w^2*(135000 + 27000i) + (816000000 + 340000000i)));
alp12(p)=(40000 + 8000i)./(w.^4 - w.^2*(135000 + 27000i) + (816000000 + 340000000i));
alp21(p)=(40000 + 8000i)./(w.^4 - w.^2*(135000 + 27000i) + (816000000 + 340000000i));
alp22(p)=-(w.^2 - 90000 - 18000i)./(2*(w.^4 - w.^2*(135000 + 27000i) + (816000000 + 340000000i)));
end
figure(1)
subplot(2,2,1);
plot(a,20*log10(abs(alp11)));
title('Bode plot- Receptance');
xlabel('mag-receptance');
ylabel('angular frequency');

subplot(2,2,2);
plot(a,20*log10(abs(alp12)));
title('Bode plot- Receptance');
xlabel('mag-receptance');
ylabel('angular frequency');

subplot(2,2,3);
plot(a,20*log10(abs(alp21)));
title('Bode plot- Receptance');
xlabel('mag-receptance');
ylabel('angular frequency');

subplot(2,2,4);
plot(a,20*log10(abs(alp22)));
title('Bode plot- Receptance');
xlabel('mag-receptance');
ylabel('angular frequency');

figure(2)
hold on
plot(a,20*log10(abs(alp11)));
plot(a,20*log10(abs(alp12)));%alp21 and alp12 gives the same value
plot(a,20*log10(abs(alp21)));
plot(a,20*log10(abs(alp22)));
title('Bode plot- Receptance');
xlabel('mag-receptance');
ylabel('angular frequency');

figure(3)
hold on
subplot(2,2,1);
plot(real(alp11),imag(alp11));
title('Nyquist Plot- Receptance');
xlabel('real-receptance');
ylabel('imaginary-receptance');

subplot(2,2,2);
plot(real(alp12),imag(alp12));
title('Nyquist Plot- Receptance');
xlabel('real-receptance');
ylabel('imaginary-receptance');

subplot(2,2,3);
plot(real(alp21),imag(alp21));
title('Nyquist Plot- Receptance');
xlabel('real-receptance');
ylabel('imaginary-receptance');

subplot(2,2,4);
plot(real(alp22),imag(alp22));
title('Nyquist Plot- Receptance');
xlabel('real-receptance');
ylabel('imaginary-receptance');

figure(4)
hold on
plot(real(alp11),imag(alp11));
plot(real(alp12),imag(alp12));
plot(real(alp21),imag(alp21));
plot(real(alp22),imag(alp22));
title('Nyquist Plot- Receptance');
xlabel('real-receptance');
ylabel('imaginary-receptance');



