clc
clear all;
close all;
%values taken from Lab2_1.m
xa1=-0.0259e-3;xa2=-0.0166e-3;xa3= -0.0070e-3;
ya1=-0.0056e-3;ya2=-0.0036e-3;ya3=-0.0025e-3;
xb1=0.0042e-3;xb2=-0.0036e-3;xb3=-0.0094e-3;
yb1=0.0054e-3;yb2=0.0127e-3;yb3=0.0079e-3;
xc1=0.0036e-3;xc2=-0.0098e-3;xc3=-0.0098e-3;
yc1=0.0087e-3;yc2=0.0029e-3;yc3=0.0033e-3;
xd1=-0.0006e-3;xd2=-0.0006e-3;xd3=-0.0007e-3;
yd1=-0.0047e-3;yd2=-0.0049e-3;yd3=-0.0050e-3; 
  
A=[2*xa1 2*ya1 1;2*xa2 2*ya2 1;2*xa3 2*ya3 1];
B=[2*xb1 2*yb1 1;2*xb2 2*yb2 1;2*xb3 2*yb3 1];
C=[2*xc1 2*yc1 1;2*xc2 2*yc2 1;2*xc3 2*yc3 1];
D=[2*xd1 2*yd1 1;2*xd2 2*yd2 1;2*xd3 2*yd3 1];

RA=A\[-xa1^2-ya1^2;-xa2^2-ya2^2;-xa3^2-ya3^2];
RB=B\[-xb1^2-yb1^2;-xb2^2-yb2^2;-xb3^2-yb3^2];
RC=C\[-xc1^2-yc1^2;-xc2^2-yc2^2;-xc3^2-yc3^2];
RD=D\[-xd1^2-yd1^2;-xd2^2-yd2^2;-xd3^2-yd3^2];
figure(1)
CA=(RA(1,1)^2+RA(2,1)^2-RA(3,1))^.5; %1/2CA we need to compare with
CB=(RB(1,1)^2+RB(2,1)^2-RB(3,1))^.5;
CC=(RC(1,1)^2+RC(2,1)^2-RC(3,1))^.5;
CD=(RD(1,1)^2+RD(2,1)^2-RD(3,1))^.5;

phi=-pi:0.1:pi; %this did not work while using for loop    
XA=-RA(1,1)+CA*cos(phi);
YA=-RA(2,1)+CA*sin(phi);
XB=-RB(1,1)+CB*cos(phi);
YB=-RB(2,1)+CB*sin(phi);
XC=-RC(1,1)+CC*cos(phi);
YC=-RC(2,1)+CC*sin(phi);
XD=-RD(1,1)+CD*cos(phi);
YD=-RD(2,1)+CD*sin(phi);
hold on
plot(XA,YA)
title('Circle Drawn from value obtained form previous receptance Data');
figure(2)
plot(XB,YB)
title('Circle Drawn from value obtained form previous receptance Data');
figure(3)
plot(XC,YC)
title('Circle Drawn from value obtained form previous receptance Data');
figure(4)
plot(XD,YD)
title('Circle Drawn from value obtained form previous receptance Data');
hold on
%CA=(RA(1,1)^2+RA(2,1)^2-RA(3,1))^.5; %1/2CA we need to compare with
dBodeA=(10^(8.5)*0.02)^0.5;% eta^2/2;
dBodeB=(10^(8.53)*0.02)^0.5;
dBodeC=(10^(8.53)*0.02)^0.5;
dBodeD=(10^(8.7)*0.02)^0.5;
dAcircleA=1/(2*CA);
dAcircleB=1/(2*CB);
dAcircleC=1/(2*CC);
dAcircleD=1/(2*CD);

PerrorA=(dBodeA-dAcircleA)/dBodeA;
PerrorB=(dBodeB-dAcircleB)/dBodeB;
PerrorC=(dBodeC-dAcircleC)/dBodeC;
PerrorD=(dBodeD-dAcircleD)/dBodeD;

% %Display
% X = ['The centre of circle 1 is ',num2str(RA(1,1)),',',numstr(RA(2,1))];
% disp(X)