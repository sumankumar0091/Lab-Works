clc
clear all
close all
m1=1;m2=2;
beta=0.02;
m=[m1 0;0 m2];
k1=10e3; k2=80e3;k3=10e3;
k=[k1+k2 -k2;-k2 k2+k3];
[V,D]=eig(m\k*(1+0.02*i));%[eigen vector eigen value];
OmgN=D.^0.5;
r=real(D);
p=imag(D);
mmass=V'*m*V;%modal mass
mk=V'*k*V;%modal stiffness
mloss=p./r;%modal damping ratio
psi1=V(:,1);
psi2=V(:,2);
phi1=V(:,1)/(mmass(1,1)^.5);
phi2=V(:,2)/(mmass(2,2)^.5);
phi=[phi1 phi2];
w=0:1:1000;
a11=(phi(1,1)*phi(1,1))./(OmgN(1,1)^2-w.^2);
a12=(phi(1,2)*phi(1,2))./(OmgN(2,2)^2-w.^2);
alp11=(a11+a12);
% alp11=(phi(1,1)*phi(1,1))./(OmgN(1,1)^2-w.^2)+phi(1,2)*phi(1,2)./(OmgN(2,2)^2-w.^2);
b11=(phi(1,1)*phi(2,1))./(D(1,1)-w.^2);
b12=(phi(1,2)*phi(2,2))./(D(2,2)-w.^2);
alp12=(phi(1,1)*phi(2,1))./(D(1,1)-w.^2)+phi(1,2)*phi(2,2)./(D(2,2)-w.^2);
% alp1=alp11+alp12;
% alp21=(phi(2,1)*phi(1,1))/D(1,1)^2-w^2+phi(1,2)*phi(2,2)/D(2,2)^2-w^2;
c11=(phi(2,1)*phi(2,1))./(D(1,1)-w.^2);
c12=(phi(2,2)*phi(2,2))./(D(2,2)-w.^2);
alp22=(c11+c12);
%alp22=(phi(2,1)*phi(2,1))./(D(1,1).^2-w.^2)+(phi(1,2)*phi(2,2))./(D(2,2).^2-w.^2);
% alp2=alp21+alp22;
figure(1)
plot(w,abs(a11));
plot(w,abs(a12));
plot(w,abs(alp11));
plot(w,abs(alp12));
xlabel('omega');
ylabel('abs(alp)');
figure(2);
hold on
semilogx(w,20*log10(a11));
semilogx(w,20*log10(a12));
semilogx(w,(20*log10(alp11)));
legend('a11','a12','a11+a12');
xlabel('omega');
ylabel('20log10(alp)');
figure(3)
plot(w,abs(b11));
plot(w,abs(b12));
plot(w,abs(alp12));
legend('a11','a12','a11+a12');
xlabel('omega');
ylabel('abs(alp)');
figure(4);
hold on
semilogx(w,20*log10(b11));
semilogx(w,20*log10(b12));
semilogx(w,(20*log10(alp12)));
legend('b11','b12','b11+b12');
xlabel('omega');
ylabel('20log10(alp)');
figure(5)
plot(w,abs(c11));
plot(w,abs(c12));
plot(w,abs(alp22));
legend('c11','c12','c11+c12');
xlabel('omega');
ylabel('abs(alp)');
figure(6);
hold on
semilogx(w,20*log10(c11));
semilogx(w,20*log10(c12));
semilogx(w,(20*log10(alp22)));
legend('c11','c12','c11+c12');
xlabel('omega');
ylabel('20log10(alp)');