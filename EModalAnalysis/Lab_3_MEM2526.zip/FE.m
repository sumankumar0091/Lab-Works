%*this program is to model FE program of Cantilever steel beam.
clc
clear all
close all
l=.540;b=.045;t=3e-3;
E=210e9;mi=b*t^3/12;
Cr_area=b*t;
rho=7800;
mass_cr=b*t*rho; 
EleNo=5;
Tnode=EleNo+1;
h=l/EleNo;
m1=mass_cr*h/420;%420
k=E*mi/h^3;
%stiffness matrix
M_matrix=[156 22*h 54 -13*h;22*h 4*h^2 13*h -3*h^2;
    54 13*h 156 -22*h;-13*h -3*h^2 -22*h 4*h^2];%2D element

K_matrix=[12 6*h -12 -6*h;6*h 4*h^2 -6*h 2*h^2;-12 -6*h 12 -6*h; 6*h 2*h^2 -6*h 4*h^2];
fM_matrix=m1*M_matrix;
fK_matrix=k*K_matrix;
cfM_matrix=zeros(2*Tnode);
cfK_matrix=zeros(2*Tnode);
for p=1:EleNo
    q=2*(p-1);
    q1=q+1;
    q4=q+4;
    cfM_matrix(q1:q4,q1:q4)=cfM_matrix(q1:q4,q1:q4)+fM_matrix;
    cfK_matrix(q1:q4,q1:q4)=cfK_matrix(q1:q4,q1:q4)+fK_matrix;
end

    bcfM_matrix=cfM_matrix(1:2*Tnode-2,1:2*Tnode-2);%boundary Condition Applied eliminating the first and second DOF
    bcfK_matrix=cfK_matrix(1:2*Tnode-2,1:2*Tnode-2);
    E_value= eig(inv(bcfM_matrix)*bcfK_matrix);%[V,D]